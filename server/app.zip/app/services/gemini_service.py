import json
import os
from flask import current_app

def _use_vertex_ai():
    api_key = current_app.config.get('GOOGLE_API_KEY')
    use_vertex = current_app.config.get('GOOGLE_GENAI_USE_VERTEXAI', False)
    return bool(api_key and use_vertex)

def _has_new_genai():
    try:
        from google import genai  # noqa: F401
        return True
    except ImportError:
        return False

def _ensure_vertex_env():
    if not _use_vertex_ai():
        return
    api_key = current_app.config.get('GOOGLE_API_KEY')
    if api_key and 'GOOGLE_API_KEY' not in os.environ:
        os.environ['GOOGLE_API_KEY'] = api_key
    if current_app.config.get('GOOGLE_GENAI_USE_VERTEXAI'):
        os.environ['GOOGLE_GENAI_USE_VERTEXAI'] = 'True'

def _gemini_client():
    from google import genai
    from google.genai.types import HttpOptions

    if _use_vertex_ai():
        _ensure_vertex_env()
        return genai.Client(http_options=HttpOptions(api_version="v1"))
    api_key = current_app.config.get('GOOGLE_GEMINI_API_KEY')
    if not api_key:
        raise ValueError("GOOGLE_GEMINI_API_KEY not configured")
    return genai.Client(api_key=api_key)

def _default_model():
    return current_app.config.get('GEMINI_MODEL_ID') or 'gemini-3-flash-preview'

def _default_model_legacy():
    return current_app.config.get('GEMINI_MODEL_ID') or 'gemini-1.5-flash'

def _generate_config():
    from google.genai import types
    level = current_app.config.get('GEMINI_THINKING_LEVEL')
    if not level:
        return None
    try:
        if hasattr(types, 'ThinkingConfig'):
            return types.GenerateContentConfig(thinking_config=types.ThinkingConfig(thinking_level=level))
        return types.GenerateContentConfig(thinking_config={'thinking_level': level})
    except Exception:
        return None

def _call_gemini_new(text):
    from google import genai

    client = _gemini_client()
    model_id = _default_model()
    prompt = _build_prompt(text)
    config = _generate_config()
    kwargs = dict(model=model_id, contents=prompt)
    if config is not None:
        kwargs['config'] = config
    response = client.models.generate_content(**kwargs)
    response_text = (getattr(response, 'text', None) or "").strip()
    if not response_text:
        raise ValueError(
            "Gemini returned no text. Check your API key and that the model is available in your project."
        )
    return _parse_response(response_text)

def _call_gemini_legacy(text):
    import google.generativeai as genai

    if _use_vertex_ai():
        raise ImportError(
            "Vertex AI requires the google-genai package. Install it with: pip install google-genai"
        )
    api_key = current_app.config.get('GOOGLE_GEMINI_API_KEY')
    if not api_key:
        raise ValueError("GOOGLE_GEMINI_API_KEY not configured")
    genai.configure(api_key=api_key)
    model_id = _default_model_legacy()
    model = genai.GenerativeModel(model_id)
    prompt = _build_prompt(text)
    response = model.generate_content(prompt)
    response_text = (response.text or "").strip()
    return _parse_response(response_text)

def _call_gemini(text):
    if _has_new_genai():
        return _call_gemini_new(text)
    return _call_gemini_legacy(text)

def _build_prompt(text):
    return f"""Analyze this Bible text and identify narrator and character speech. Create SEPARATE chunks for each distinct element.

CHUNK TYPES (create separate chunks for each):
1. Book title: Standalone book names in ALL CAPS or title case (e.g., "GENEZA", "Geneza") → chunk_type: "book_title"
2. Chapter number: Lines like "Capitolul 1", "Chapter 1", "Capitolul 2" → chunk_type: "chapter_number"
3. Chapter name/subtitle: Descriptive text after chapter number (e.g., "Vremurile străvechi de la facerea lumii până la Avraam") → chunk_type: "chapter_name"
4. Section titles: Short descriptive titles (e.g., "Facerea lumii", "Lumina", "Cerul", "Pământul") → chunk_type: "section_title"
5. Verses: Numbered verses with text (e.g., "1. La început, Dumnezeu a făcut cerurile şi pământul.") → chunk_type: "verse"
6. Character speech: Direct quotes from characters (e.g., Dumnezeu says "Să fie lumină!") → chunk_type: "verse", role: "character"

RULES:
- Extract verse references separately. Reference lines look like "Ioan 1:1, 2; Evr. 1:10. **Ps. 8:3; Ps. 33:6; ..." or " *Ps. 33:6; Isa. 40:13"
- For each verse chunk, extract its references into a "references" array. Parse references like: "Ioan 1:1, 2" → ["Ioan 1:1", "Ioan 1:2"], "Ps. 8:3" → ["Ps. 8:3"]
- Remove footnote markers (\\*, \\**, †, _) from the main text, but extract references before removing markers.
- The "text" field should be clean for speech (no reference lines, no footnote symbols).
- Each verse (with its number) should be ONE separate chunk.
- Book titles, chapter numbers, and chapter names must be separate chunks, not combined.
- Section titles are typically short phrases (1-5 words) that describe a section.

Return JSON with this exact structure:
{{
  "chunks": [
    {{
      "text": "clean text to be read aloud (no reference lines, no footnote symbols)",
      "role": "narrator" or "character",
      "character_name": null or "character name",
      "chunk_type": "book_title" or "chapter_number" or "chapter_name" or "section_title" or "verse",
      "references": ["Ioan 1:1", "Evr. 1:10", "Ps. 8:3"] or null (only for verse chunks with references),
      "position": 1
    }}
  ]
}}

Text to analyze:
{text}

Return only valid JSON, no additional text."""

def _parse_response(response_text):
    if response_text.startswith('```json'):
        response_text = response_text.replace('```json', '').replace('```', '').strip()
    elif response_text.startswith('```'):
        response_text = response_text.replace('```', '').strip()

    result = json.loads(response_text)
    if 'chunks' not in result:
        raise ValueError("Invalid response format: missing 'chunks' key")

    for i, chunk in enumerate(result['chunks'], start=1):
        if 'position' not in chunk:
            chunk['position'] = i
        if 'chunk_type' not in chunk:
            chunk['chunk_type'] = 'verse'
        if 'references' not in chunk:
            chunk['references'] = None
    return result['chunks']

def analyze_text_chunks(text):
    if not (text or "").strip():
        raise ValueError("No text provided to analyze")
    try:
        return _call_gemini(text)
    except (ValueError, json.JSONDecodeError):
        raise
    except Exception as e:
        raise Exception(f"Gemini API error: {e}") from e

def analyze_text_in_batches(text, max_chunk_size=30000):
    if len(text) <= max_chunk_size:
        return analyze_text_chunks(text)

    chunks = []
    words = text.split()
    current_chunk = []
    current_size = 0

    for word in words:
        word_size = len(word) + 1
        if current_size + word_size > max_chunk_size and current_chunk:
            chunk_text = ' '.join(current_chunk)
            batch_chunks = analyze_text_chunks(chunk_text)
            chunks.extend(batch_chunks)
            current_chunk = [word]
            current_size = word_size
        else:
            current_chunk.append(word)
            current_size += word_size

    if current_chunk:
        chunk_text = ' '.join(current_chunk)
        batch_chunks = analyze_text_chunks(chunk_text)
        chunks.extend(batch_chunks)

    for i, chunk in enumerate(chunks, start=1):
        chunk['position'] = i

    return chunks
