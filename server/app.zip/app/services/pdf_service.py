import os
import pdfplumber
from langdetect import detect, LangDetectException
from app.utils.text_cleaner import clean_text, normalize_whitespace
from app.utils.file_handler import generate_file_hash
from flask import current_app

LANGUAGE_NAMES = {
    'en': 'English',
    'ro': 'Romanian',
    'de': 'German',
    'fr': 'French',
    'es': 'Spanish',
    'it': 'Italian',
    'pt': 'Portuguese'
}

def detect_pdf_language(text):
    if not text or len(text) < 100:
        return 'en', 'English'
    
    text_sample = text[:2000] if len(text) > 2000 else text
    
    try:
        lang_code = detect(text_sample)
        lang_name = LANGUAGE_NAMES.get(lang_code, lang_code.upper())
        return lang_code, lang_name
    except LangDetectException:
        return 'en', 'English'

def extract_text_from_pdf(file_path):
    try:
        max_pages = 5
        if current_app:
            max_pages = int(current_app.config.get('MAX_PDF_PAGES', 5))
        max_pages = max(1, min(max_pages, 999))
        raw_text = ""
        with pdfplumber.open(file_path) as pdf:
            total_pages = len(pdf.pages)
            pages_to_process = min(max_pages, total_pages)
            for i in range(pages_to_process):
                page_text = pdf.pages[i].extract_text()
                if page_text:
                    raw_text += page_text + "\n"
        cleaned_text = clean_text(raw_text)
        cleaned_text = normalize_whitespace(cleaned_text)
        if total_pages > max_pages:
            raw_text += f"\n[Truncated: first {pages_to_process} of {total_pages} pages only (MAX_PDF_PAGES={max_pages}).]"
        return raw_text, cleaned_text
    except Exception as e:
        raise Exception(f"Failed to extract text from PDF: {str(e)}")

def process_pdf_file(file_path):
    file_hash = generate_file_hash(file_path)
    raw_text, cleaned_text = extract_text_from_pdf(file_path)
    language_code, language_name = detect_pdf_language(cleaned_text)
    
    return {
        'file_hash': file_hash,
        'raw_text': raw_text,
        'cleaned_text': cleaned_text,
        'language_code': language_code,
        'language_name': language_name
    }
