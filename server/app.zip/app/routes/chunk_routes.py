from flask import Blueprint, request, jsonify
from app.database import db
from app.models import PDF, Chunk, ExtractedText, VoiceSetting
from app.services.gemini_service import analyze_text_in_batches
from app.services.pdf_service import detect_pdf_language
import json

bp = Blueprint('chunks', __name__)

@bp.route('/pdf/<int:pdf_id>/chunks', methods=['GET'])
def get_chunks(pdf_id):
    pdf = PDF.query.get_or_404(pdf_id)
    chunks = Chunk.query.filter_by(pdf_id=pdf_id).order_by(Chunk.position).all()
    return jsonify([chunk.to_dict() for chunk in chunks])

@bp.route('/pdf/<int:pdf_id>/characters', methods=['GET'])
def get_characters(pdf_id):
    pdf = PDF.query.get_or_404(pdf_id)
    chunks = Chunk.query.filter_by(pdf_id=pdf_id).all()
    
    characters = []
    seen = set()
    
    for chunk in chunks:
        if chunk.role == 'narrator':
            key = 'narrator'
        else:
            key = f"{chunk.role}_{chunk.character_name or 'unknown'}"
        
        if key not in seen:
            seen.add(key)
            characters.append({
                'role': chunk.role,
                'character_name': chunk.character_name
            })
    
    return jsonify(characters)

@bp.route('/pdf/<int:pdf_id>/analyze', methods=['POST'])
def analyze_pdf(pdf_id):
    pdf = PDF.query.get_or_404(pdf_id)
    
    existing_chunks = Chunk.query.filter_by(pdf_id=pdf_id).first()
    if existing_chunks:
        chunks = Chunk.query.filter_by(pdf_id=pdf_id).order_by(Chunk.position).all()
        return jsonify([chunk.to_dict() for chunk in chunks]), 200
    
    extracted_text = ExtractedText.query.filter_by(pdf_id=pdf_id).first()
    if not extracted_text:
        return jsonify({'error': 'Text not extracted. Process PDF first'}), 400
    
    try:
        chunks_data = analyze_text_in_batches(extracted_text.cleaned_text)
        
        chunks_to_add = []
        for chunk_data in chunks_data:
            references = chunk_data.get('references')
            references_json = json.dumps(references) if references else None
            chunks_to_add.append(Chunk(
                pdf_id=pdf_id,
                text=chunk_data['text'],
                role=chunk_data['role'],
                character_name=chunk_data.get('character_name'),
                chunk_type=chunk_data.get('chunk_type', 'verse'),
                references=references_json,
                position=chunk_data['position']
            ))
        db.session.add_all(chunks_to_add)
        
        db.session.commit()
        
        chunks = Chunk.query.filter_by(pdf_id=pdf_id).order_by(Chunk.position).all()
        return jsonify([chunk.to_dict() for chunk in chunks]), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500
